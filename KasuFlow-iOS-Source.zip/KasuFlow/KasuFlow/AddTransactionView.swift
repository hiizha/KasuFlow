import SwiftUI

struct AddTransactionView: View {
    @EnvironmentObject var store: FinanceStore
    @Environment(\.dismiss) private var dismiss
    @State private var type: TransactionType = .expense
    @State private var title = ""
    @State private var amount = ""
    @State private var category = "Makanan"
    @State private var date = Date()
    @State private var note = ""

    private let incomeCategories = ["Gaji", "Bonus", "Hadiah", "Lainnya"]
    private let expenseCategories = ["Makanan", "Transportasi", "Belanja", "Tagihan", "Hiburan", "Lainnya"]
    private let mint = Color(red: 0.42, green: 0.88, blue: 0.68)
    private let panel = Color(red: 0.10, green: 0.15, blue: 0.16)

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.055, green: 0.09, blue: 0.105).ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Picker("Jenis transaksi", selection: $type) {
                            ForEach(TransactionType.allCases) { item in Text(item.rawValue).tag(item) }
                        }
                        .pickerStyle(.segmented)
                        .onChange(of: type) { _, newValue in
                            category = newValue == .income ? incomeCategories[0] : expenseCategories[0]
                        }

                        VStack(alignment: .leading, spacing: 8) {
                            Text("NOMINAL (¥)").font(.caption.bold()).tracking(1).foregroundStyle(.white.opacity(0.55))
                            HStack {
                                Text("¥").font(.system(size: 27, weight: .bold)).foregroundStyle(mint)
                                TextField("0", text: $amount)
                                    .keyboardType(.decimalPad)
                                    .font(.system(size: 32, weight: .bold, design: .rounded))
                                    .foregroundStyle(.white)
                            }
                            .padding(16)
                            .background(panel, in: RoundedRectangle(cornerRadius: 16))
                        }

                        field("Nama transaksi") {
                            TextField("Contoh: Makan siang", text: $title)
                                .textInputAutocapitalization(.sentences)
                        }

                        VStack(alignment: .leading, spacing: 8) {
                            Text("KATEGORI").font(.caption.bold()).tracking(1).foregroundStyle(.white.opacity(0.55))
                            Picker("Kategori", selection: $category) {
                                ForEach(type == .income ? incomeCategories : expenseCategories, id: \.self) { Text($0).tag($0) }
                            }
                            .tint(mint)
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(panel, in: RoundedRectangle(cornerRadius: 14))
                        }

                        VStack(alignment: .leading, spacing: 8) {
                            Text("TANGGAL").font(.caption.bold()).tracking(1).foregroundStyle(.white.opacity(0.55))
                            DatePicker("Tanggal transaksi", selection: $date, displayedComponents: .date)
                                .datePickerStyle(.compact)
                                .tint(mint)
                                .foregroundStyle(.white)
                                .padding(12)
                                .background(panel, in: RoundedRectangle(cornerRadius: 14))
                        }

                        field("Catatan (opsional)") {
                            TextField("Tambahkan detail...", text: $note)
                        }

                        Button(action: save) {
                            Text("Simpan transaksi")
                                .font(.system(size: 16, weight: .bold))
                                .foregroundStyle(Color(red: 0.055, green: 0.09, blue: 0.105))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 16)
                                .background(mint, in: Capsule())
                        }
                        .disabled(!canSave)
                        .opacity(canSave ? 1 : 0.45)
                    }
                    .padding(20)
                }
            }
            .navigationTitle("Transaksi baru")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Batal") { dismiss() }.foregroundStyle(mint)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var canSave: Bool {
        !title.trimmingCharacters(in: .whitespaces).isEmpty &&
        (Double(amount.replacingOccurrences(of: ",", with: ".")) ?? 0) > 0
    }

    @ViewBuilder
    private func field<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title.uppercased()).font(.caption.bold()).tracking(1).foregroundStyle(.white.opacity(0.55))
            content()
                .font(.system(size: 15))
                .foregroundStyle(.white)
                .padding(15)
                .background(panel, in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private func save() {
        guard let value = Double(amount.replacingOccurrences(of: ",", with: ".")), value > 0 else { return }
        let item = MoneyTransaction(title: title.trimmingCharacters(in: .whitespaces), amount: value, type: type, category: category, date: date, note: note)
        store.add(item)
        dismiss()
    }
}
