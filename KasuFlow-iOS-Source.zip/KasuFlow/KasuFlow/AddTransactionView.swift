import SwiftUI

struct AddTransactionView: View {
    @EnvironmentObject var store: FinanceStore
    @Environment(\.dismiss) private var dismiss

    @State private var type: TransactionType = .expense
    @State private var title = ""
    @State private var amount = ""
    @State private var category = "Makanan"
    @State private var date = Date()
    @State private var note = ""

    private let incomeCategories = ["Gaji", "Bonus", "Hadiah", "Lainnya"]
    private let expenseCategories = ["Makanan", "Transportasi", "Belanja", "Tagihan", "Hiburan", "Lainnya"]
    private let mint = Color(red: 0.42, green: 0.88, blue: 0.68)
    private let panel = Color(red: 0.10, green: 0.15, blue: 0.16)
    private let backgroundColor = Color(red: 0.055, green: 0.09, blue: 0.105)

    var body: some View {
        NavigationStack {
            ZStack {
                backgroundColor.ignoresSafeArea()
                formContent
            }
            .navigationTitle("Transaksi baru")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Batal") {
                        dismiss()
                    }
                    .foregroundStyle(mint)
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private var formContent: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                transactionTypePicker
                amountSection
                nameSection
                categorySection
                dateSection
                noteSection
                saveButton
            }
            .padding(20)
        }
    }

    private var transactionTypePicker: some View {
        Picker("Jenis transaksi", selection: $type) {
            ForEach(TransactionType.allCases) { item in
                Text(item.rawValue).tag(item)
            }
        }
        .pickerStyle(.segmented)
        .onChange(of: type) { newValue in
            category = newValue == .income ? incomeCategories[0] : expenseCategories[0]
        }
    }

    private var amountSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionLabel("NOMINAL (¥)")
            HStack {
                Text("¥")
                    .font(.system(size: 27, weight: .bold))
                    .foregroundStyle(mint)

                TextField("0", text: $amount)
                    .keyboardType(.decimalPad)
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            }
            .padding(16)
            .background(panel, in: RoundedRectangle(cornerRadius: 16))
        }
    }

    private var nameSection: some View {
        field("Nama transaksi") {
            TextField("Contoh: Makan siang", text: $title)
                .textInputAutocapitalization(.sentences)
        }
    }

    private var categorySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionLabel("KATEGORI")
            Picker("Kategori", selection: $category) {
                ForEach(currentCategories, id: \.self) { item in
                    Text(item).tag(item)
                }
            }
            .tint(mint)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(panel, in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private var currentCategories: [String] {
        if type == .income {
            return incomeCategories
        }
        return expenseCategories
    }

    private var dateSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionLabel("TANGGAL")
            DatePicker("Tanggal transaksi", selection: $date, displayedComponents: .date)
                .datePickerStyle(.compact)
                .tint(mint)
                .foregroundStyle(.white)
                .padding(12)
                .background(panel, in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private var noteSection: some View {
        field("Catatan (opsional)") {
            TextField("Tambahkan detail...", text: $note)
        }
    }

    private var saveButton: some View {
        Button(action: save) {
            Text("Simpan transaksi")
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(backgroundColor)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(mint, in: Capsule())
        }
        .disabled(!canSave)
        .opacity(canSave ? 1 : 0.45)
    }

    private var canSave: Bool {
        let cleanTitle = title.trimmingCharacters(in: .whitespaces)
        let normalizedAmount = amount.replacingOccurrences(of: ",", with: ".")
        let numericAmount = Double(normalizedAmount) ?? 0
        return !cleanTitle.isEmpty && numericAmount > 0
    }

    private func sectionLabel(_ text: String) -> some View {
        Text(text)
            .font(.caption.bold())
            .tracking(1)
            .foregroundStyle(.white.opacity(0.55))
    }

    @ViewBuilder
    private func field<Content: View>(
        _ title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionLabel(title.uppercased())
            content()
                .font(.system(size: 15))
                .foregroundStyle(.white)
                .padding(15)
                .background(panel, in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private func save() {
        let normalizedAmount = amount.replacingOccurrences(of: ",", with: ".")
        guard let value = Double(normalizedAmount), value > 0 else {
            return
        }

        let cleanTitle = title.trimmingCharacters(in: .whitespaces)
        let item = MoneyTransaction(
            title: cleanTitle,
            amount: value,
            type: type,
            category: category,
            date: date,
            note: note
        )
        store.add(item)
        dismiss()
    }
}
