import SwiftUI

enum TransactionType: String, Codable, CaseIterable, Identifiable {
    case income = "Pemasukan"
    case expense = "Pengeluaran"
    var id: String { rawValue }
}

struct MoneyTransaction: Identifiable, Codable {
    var id = UUID()
    var title: String
    var amount: Double
    var type: TransactionType
    var category: String
    var date: Date
    var note: String
}

final class FinanceStore: ObservableObject {
    @Published var transactions: [MoneyTransaction] = [] {
        didSet { save() }
    }

    private let key = "kasuflow.transactions"

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([MoneyTransaction].self, from: data) {
            transactions = saved
        } else {
            transactions = []
        }
    }

    var income: Double {
        transactions.filter { $0.type == .income }.reduce(0) { $0 + $1.amount }
    }

    var expense: Double {
        transactions.filter { $0.type == .expense }.reduce(0) { $0 + $1.amount }
    }

    var balance: Double { income - expense }

    func add(_ item: MoneyTransaction) {
        transactions.insert(item, at: 0)
    }

    func update(_ item: MoneyTransaction) {
        guard let index = transactions.firstIndex(where: { $0.id == item.id }) else { return }
        transactions[index] = item
    }

    func delete(at offsets: IndexSet) {
        transactions.remove(atOffsets: offsets)
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(transactions) else { return }
        UserDefaults.standard.set(data, forKey: key)
    }
}
