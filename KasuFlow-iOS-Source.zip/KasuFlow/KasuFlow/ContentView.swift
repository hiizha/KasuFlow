import SwiftUI

private let ink = Color(red: 0.055, green: 0.09, blue: 0.105)
private let panel = Color(red: 0.10, green: 0.15, blue: 0.16)
private let mint = Color(red: 0.42, green: 0.88, blue: 0.68)

struct ContentView: View {
    @EnvironmentObject var store: FinanceStore
    @State private var showingAdd = false
    @State private var selectedFilter = "Semua"

    private var filtered: [MoneyTransaction] {
        switch selectedFilter {
        case "Masuk": return store.transactions.filter { $0.type == .income }
        case "Keluar": return store.transactions.filter { $0.type == .expense }
        default: return store.transactions
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                ink.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 22) {
                        header
                        balanceCard
                        summaryRow
                        transactionHeader
                        filterBar
                        transactionList
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 12)
                    .padding(.bottom, 110)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(ink.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .safeAreaInset(edge: .bottom, spacing: 0) {
                Button { showingAdd = true } label: {
                    Label("Tambah transaksi", systemImage: "plus")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(ink)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 17)
                        .background(mint, in: Capsule())
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 8)
                .background(ink.opacity(0.96))
            }
            .sheet(isPresented: $showingAdd) {
                AddTransactionView()
                    .environmentObject(store)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
            }
        }
        .tint(mint)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(ink.ignoresSafeArea(.all))
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text("CASHFLOW")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .tracking(2.2)
                    .foregroundStyle(mint)
                Text("Keuanganmu, lebih teratur.")
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            }
            Spacer()
            Menu {
                Picker("Mata uang", selection: $store.currencyCode) {
                    ForEach(FinanceStore.currencyCodes, id: \.self) { code in
                        Text(store.currencyName(code)).tag(code)
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "globe")
                    Text(store.currencyCode)
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                    Image(systemName: "chevron.down")
                        .font(.system(size: 9, weight: .bold))
                }
                .foregroundStyle(mint)
                .padding(.horizontal, 11)
                .padding(.vertical, 10)
                .background(panel, in: Capsule())
            }
        }
    }

    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label("TOTAL SALDO", systemImage: "circle.grid.2x2.fill")
                    .font(.system(size: 11, weight: .bold))
                    .tracking(1.2)
                    .foregroundStyle(.white.opacity(0.72))
                Spacer()
                Text(store.currencyCode)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(ink)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.white.opacity(0.72), in: Capsule())
            }
            Text(store.balance, format: .currency(code: store.currencyCode))
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .minimumScaleFactor(0.65)
                .lineLimit(1)
                .foregroundStyle(.white)
            HStack(spacing: 7) {
                Image(systemName: "chart.line.uptrend.xyaxis")
                Text("Ringkasan seluruh transaksi")
            }
            .font(.system(size: 12, weight: .medium))
            .foregroundStyle(.white.opacity(0.72))
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            LinearGradient(colors: [Color(red: 0.12, green: 0.39, blue: 0.31), Color(red: 0.08, green: 0.23, blue: 0.21)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 25, style: .continuous)
        )
        .overlay(alignment: .bottomTrailing) {
            Circle().stroke(.white.opacity(0.08), lineWidth: 25).frame(width: 120).offset(x: 25, y: 35).clipped()
        }
        .clipShape(RoundedRectangle(cornerRadius: 25, style: .continuous))
    }

    private var summaryRow: some View {
        HStack(spacing: 12) {
            SummaryCard(title: "Pemasukan", amount: store.income, currencyCode: store.currencyCode, icon: "arrow.down.left", color: mint)
            SummaryCard(title: "Pengeluaran", amount: store.expense, currencyCode: store.currencyCode, icon: "arrow.up.right", color: Color(red: 1, green: 0.55, blue: 0.48))
        }
    }

    private var transactionHeader: some View {
        HStack {
            Text("Transaksi")
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Spacer()
            Text("\(store.transactions.count) catatan")
                .font(.system(size: 12, weight: .medium))
                .foregroundStyle(.white.opacity(0.45))
        }
    }

    private var filterBar: some View {
        HStack(spacing: 8) {
            ForEach(["Semua", "Masuk", "Keluar"], id: \.self) { item in
                Button { selectedFilter = item } label: {
                    Text(item)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(selectedFilter == item ? ink : .white.opacity(0.65))
                        .padding(.horizontal, 16)
                        .padding(.vertical, 9)
                        .background(selectedFilter == item ? mint : panel, in: Capsule())
                }
            }
        }
    }

    private var transactionList: some View {
        VStack(spacing: 10) {
            if filtered.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tray")
                        .font(.system(size: 27))
                        .foregroundStyle(mint.opacity(0.8))
                    Text("Belum ada transaksi")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.white)
                    Text("Tekan tombol di bawah untuk mencatat uang masuk atau keluar.")
                        .font(.system(size: 12))
                        .foregroundStyle(.white.opacity(0.45))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 35)
                .background(panel, in: RoundedRectangle(cornerRadius: 20))
            } else {
                ForEach(filtered) { item in
                    TransactionRow(item: item)
                        .contextMenu {
                            Button(role: .destructive) {
                                if let index = store.transactions.firstIndex(where: { $0.id == item.id }) {
                                    store.transactions.remove(at: index)
                                }
                            } label: {
                                Label("Hapus transaksi", systemImage: "trash")
                            }
                        }
                }
            }
        }
    }
}

struct SummaryCard: View {
    let title: String
    let amount: Double
    let currencyCode: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 7) {
                Image(systemName: icon).foregroundStyle(color)
                Text(title).foregroundStyle(.white.opacity(0.65))
            }
            .font(.system(size: 12, weight: .semibold))
            Text(amount, format: .currency(code: currencyCode))
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .background(panel, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
    }
}

struct TransactionRow: View {
    @EnvironmentObject var store: FinanceStore
    let item: MoneyTransaction
    private var isIncome: Bool { item.type == .income }

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: iconFor(item.category))
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(isIncome ? mint : Color.orange)
                .frame(width: 43, height: 43)
                .background((isIncome ? mint : Color.orange).opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white)
                Text("\(item.category) · \(item.date.formatted(date: .abbreviated, time: .omitted))")
                    .font(.system(size: 11)).foregroundStyle(.white.opacity(0.45))
            }
            Spacer(minLength: 4)
            Text("\(isIncome ? "+" : "−")\(item.amount, format: .currency(code: store.currencyCode))")
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(isIncome ? mint : Color(red: 1, green: 0.55, blue: 0.48))
        }
        .padding(13)
        .background(panel, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func iconFor(_ category: String) -> String {
        switch category {
        case "Gaji": return "briefcase.fill"
        case "Makanan": return "fork.knife"
        case "Transportasi": return "tram.fill"
        case "Belanja": return "bag.fill"
        case "Tagihan": return "receipt"
        case "Hiburan": return "gamecontroller.fill"
        case "Hadiah": return "gift.fill"
        default: return "banknote"
        }
    }
}
