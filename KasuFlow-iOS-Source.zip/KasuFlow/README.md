# CashFlow — iOS Personal Money Tracker

Aplikasi pencatat pemasukan dan pengeluaran menggunakan SwiftUI. Data disimpan lokal di iPhone melalui UserDefaults; tidak membutuhkan akun atau koneksi internet.

## Identitas aplikasi
- Nama tampilan: CashFlow
- Bundle ID: `com.cashflow.tezha`
- iOS minimum: 16.0
- Ikon: dompet dan uang multi-mata-uang

## Fitur
- Ringkasan saldo, pemasukan, dan pengeluaran
- Pemilih seluruh kode mata uang ISO 4217 yang tersedia di iOS (misalnya JPY, IDR, USD, EUR, GBP)
- Format simbol dan angka mengikuti mata uang yang dipilih
- Tambah transaksi masuk/keluar, kategori, tanggal, dan catatan
- Filter riwayat dan hapus transaksi
- Layout SwiftUI adaptif untuk ukuran layar iPhone yang berbeda
- Data disimpan lokal di perangkat

## Catatan mata uang
Pemilihan mata uang mengubah simbol dan format tampilan nominal. Aplikasi ini belum melakukan konversi nilai tukar otomatis; nominal transaksi yang sudah dicatat tidak dikonversi saat mata uang tampilan diganti.

## Build dan sideload tanpa Mac
Gunakan GitHub Actions dengan workflow iOS unsigned build yang sudah dibuat sebelumnya. Ganti ZIP source di repository dengan file revisi ini, tetap gunakan nama file source ZIP yang diminta oleh workflow lama. Setelah workflow berhasil, unduh IPA unsigned dari Artifacts dan impor ke SideStore untuk ditandatangani serta dipasang.
