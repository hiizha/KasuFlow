# CashFlow iOS

Aplikasi pencatat pemasukan dan pengeluaran berbasis SwiftUI.

- Display name: CashFlow
- Bundle identifier: com.cashflow.tezha
- Target: iPhone (iOS 16+)
- Layout: full-screen adaptive SwiftUI layout; scrollable content and bottom action respect iPhone safe areas.

## Build melalui GitHub Actions

Gunakan workflow iOS build yang sudah disiapkan pada repository. Pastikan scheme/target disesuaikan menjadi `CashFlow` jika workflow memanggil scheme secara eksplisit.
