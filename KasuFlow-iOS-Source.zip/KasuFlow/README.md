# KasuFlow — iOS Personal Money Tracker

Aplikasi pencatat pemasukan dan pengeluaran sederhana menggunakan SwiftUI. Data disimpan secara lokal di perangkat melalui `UserDefaults`; tidak membutuhkan akun, server, atau koneksi internet.

## Fitur
- Ringkasan saldo, pemasukan, dan pengeluaran dalam Yen (JPY)
- Tambah transaksi masuk/keluar
- Kategori transaksi dan tanggal
- Filter riwayat
- Hapus transaksi melalui tekan lama pada item
- Tampilan dark mode

## Persyaratan
- Mac dengan Xcode 15 atau lebih baru
- iOS 16.0+
- Apple ID untuk signing perangkat pribadi

## Cara build dan sideload
1. Ekstrak ZIP ini di Mac.
2. Buka `KasuFlow.xcodeproj` menggunakan Xcode.
3. Hubungkan iPhone ke Mac, lalu pilih iPhone sebagai Run Destination.
4. Buka **Signing & Capabilities** → aktifkan **Automatically manage signing**.
5. Pilih Team / Apple ID milik sendiri. Jika diminta, ubah Bundle Identifier menjadi unik.
6. Tekan **Run**. Xcode akan build, sign, dan memasang aplikasi ke iPhone.
7. Jika diminta di iPhone, izinkan Developer App pada Settings → General → VPN & Device Management.

## Catatan
- Project ini berisi source code dan konfigurasi Xcode, bukan IPA yang sudah ditandatangani.
- Untuk membuat IPA yang bisa dipasang, diperlukan proses build dan signing menggunakan Xcode pada Mac atau tool signing yang sesuai.
- Data transaksi tersimpan di perangkat. Menghapus aplikasi dapat menghapus data lokalnya.
